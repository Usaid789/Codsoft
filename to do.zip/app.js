function addtodo(){
    var input = document.getElementById("todo-input");
    // console.log(input.value);

    var list = document.getElementById("listItems");

    var listElement = document.createElement("li");

    var listText = document.createTextNode(input.value);

    listElement.appendChild(listText);

    // Delete Button //

    var delBtn = document.createElement("button");

    var delBtnText = document.createTextNode("Delete");

    delBtn.appendChild(delBtnText);

    delBtn.setAttribute("onclick","delTodo(this)");

    listElement.appendChild(delBtn);

    // Edit Button //

    var editBtn = document.createElement("button");

    var editBtnText = document.createTextNode("Edit");

    editBtn.appendChild(editBtnText);

    listElement.appendChild(editBtn);

    list.appendChild(listElement);

    editBtn.setAttribute("onclick","editTodo(this)");

    console.log(listElement);

    input.value = "";
}

function deletetodo(){
    
    var list = document.getElementById("listItems");
    list.innerHTML = "";
}

function delTodo(e){
    console.log(e.parentNode.remove());
}

function editTodo(e){
    var currentLi = e.parentNode.firstChild.nodeValue;
    var inputFeild = prompt("Enter updated value");

    e.parentNode.firstChild.nodeValue = inputFeild;
}